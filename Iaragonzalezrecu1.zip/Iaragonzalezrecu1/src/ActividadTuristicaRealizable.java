package iaragonzalezrecu1;

public interface ActividadTuristicaRealizable {
    void realizarActividad();
}
