package iaragonzalezrecu1;

public enum ActividadTuristica {
    CAMPING, SENDERISMO, SAFARI
}
