package iaragonzalezrecu1;

import java.time.LocalDate;
import java.util.List;

public class SantuarioDeVidaSilvestre extends AreaProtegida {
    private List<Especie> especiesProtegidas;

    public SantuarioDeVidaSilvestre(String nombre, double superficie, LocalDate fechaDeEstablecimiento, List<Especie> especiesProtegidas) {
        super(nombre, superficie, fechaDeEstablecimiento);
        this.especiesProtegidas = especiesProtegidas;
    }

    @Override
    public String toString() {
        return super.toString() + ", Especies protegidas: " + especiesProtegidas;
    }

    @Override
    public void realizarActividad() {
        System.out.println("Los santuarios de vida silvestre no permiten actividades turísticas.");
    }
}
