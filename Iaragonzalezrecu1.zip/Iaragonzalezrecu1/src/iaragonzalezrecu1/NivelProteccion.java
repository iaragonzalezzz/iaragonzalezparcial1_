package iaragonzalezrecu1;

public enum NivelProteccion {
    BAJO, MEDIO, ALTO
}
