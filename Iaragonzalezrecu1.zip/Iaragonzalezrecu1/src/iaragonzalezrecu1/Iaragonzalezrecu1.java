package iaragonzalezrecu1;

import java.time.LocalDate;
import java.util.Arrays;

public class Iaragonzalezrecu1 {
    public static void main(String[] args) {
        SistemaAreas sistema = new SistemaAreas();


        ParqueNacional parque = new ParqueNacional("Monte Verde", 1500, LocalDate.of(1995, 6, 12), Arrays.asList(ActividadTuristica.CAMPING, ActividadTuristica.SENDERISMO));
        ReservaNatural reserva = new ReservaNatural("Bosque Nuboso", 2000, LocalDate.of(1980, 8, 3), NivelProteccion.ALTO);
        SantuarioDeVidaSilvestre santuario = new SantuarioDeVidaSilvestre("Isla Tortuga", 1200, LocalDate.of(2005, 4, 15), Arrays.asList(new Especie("Chelonia mydas")));

        try {
            sistema.agregarArea(parque);
            System.out.println("Area agregada: " + parque.getNombre());
        } catch (AreaRepetidaException e) {
            System.out.println(e.getMessage());
        }

        try {
            sistema.agregarArea(parque); 
        } catch (AreaRepetidaException e) {
            System.out.println(e.getMessage());
        }

        sistema.agregarArea(reserva);
        sistema.agregarArea(santuario);

        System.out.println("\nAreas protegidas:");
        sistema.mostrarAreas();


        System.out.println("\nActividades:");
        sistema.realizarActividad();
    }
}
