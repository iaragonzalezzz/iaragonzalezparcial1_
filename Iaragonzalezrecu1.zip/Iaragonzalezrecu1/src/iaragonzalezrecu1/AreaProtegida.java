package iaragonzalezrecu1;

import java.time.LocalDate;

public abstract class AreaProtegida {
    private String nombre;
    private double superficie;
    private LocalDate fechaDeEstablecimiento;

    public AreaProtegida(String nombre, double superficie, LocalDate fechaDeEstablecimiento) {
        this.nombre = nombre;
        this.superficie = superficie;
        this.fechaDeEstablecimiento = fechaDeEstablecimiento;
    }

    public String getNombre() {
        return nombre;
    }

    public double getSuperficie() {
        return superficie;
    }

    public LocalDate getFechaDeEstablecimiento() {
        return fechaDeEstablecimiento;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        AreaProtegida area = (AreaProtegida) obj;
        return nombre.equals(area.nombre) && fechaDeEstablecimiento.equals(area.fechaDeEstablecimiento);
    }

    @Override
    public int hashCode() {
        return nombre.hashCode() + fechaDeEstablecimiento.hashCode();
    }

    @Override
    public String toString() {
        return "Nombre: " + nombre + ", Superficie: " + superficie + " hectareas, Fecha de establecimiento: " + fechaDeEstablecimiento;
    }

    public abstract void realizarActividad();
}
