package iaragonzalezrecu1;

import java.util.ArrayList;
import java.util.List;

public class SistemaAreas {
    private List<AreaProtegida> areas;

    public SistemaAreas() {
        areas = new ArrayList<>();
    }

    public void agregarArea(AreaProtegida area) {
        for (AreaProtegida a : areas) {
            if (a.getNombre().equals(area.getNombre()) && a.getFechaDeEstablecimiento().equals(area.getFechaDeEstablecimiento())) {
                throw new AreaRepetidaException("Ya existe un area con el nombre y fecha de establecimiento: " + area.getNombre());
            }
        }
        areas.add(area);
    }

    public void mostrarAreas() {
        for (AreaProtegida area : areas) {
            System.out.println(area);
        }
    }

    public void realizarActividad() {
        for (AreaProtegida area : areas) {
            if (area instanceof ParqueNacional) {
                System.out.println("Actividad realizada en Parque Nacional: " + area.getNombre());
            } else {
                System.out.println("El area " + area.getNombre() + " no permite actividades turisticas.");
            }
        }
    }
}

