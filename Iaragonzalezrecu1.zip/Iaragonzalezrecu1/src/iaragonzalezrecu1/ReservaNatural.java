package iaragonzalezrecu1;

import java.time.LocalDate;

public class ReservaNatural extends AreaProtegida {
    private NivelProteccion nivelProteccion;

    public ReservaNatural(String nombre, double superficie, LocalDate fechaDeEstablecimiento, NivelProteccion nivelProteccion) {
        super(nombre, superficie, fechaDeEstablecimiento);
        this.nivelProteccion = nivelProteccion;
    }

    @Override
    public String toString() {
        return super.toString() + ", Nivel de proteccion: " + nivelProteccion;
    }

    @Override
    public void realizarActividad() {
        System.out.println("Las reservas naturales no permiten actividades turisticas.");
    }
}
