package iaragonzalezrecu1;

public class AreaRepetidaException extends RuntimeException {
    public AreaRepetidaException(String mensaje) {
        super(mensaje);
    }
}
