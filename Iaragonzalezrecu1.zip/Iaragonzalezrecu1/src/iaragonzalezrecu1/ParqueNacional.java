package iaragonzalezrecu1;

import java.time.LocalDate;
import java.util.List;

public class ParqueNacional extends AreaProtegida {
    private List<ActividadTuristica> actividadesTuristicas;

    public ParqueNacional(String nombre, double superficie, LocalDate fechaDeEstablecimiento, List<ActividadTuristica> actividadesTuristicas) {
        super(nombre, superficie, fechaDeEstablecimiento);
        this.actividadesTuristicas = actividadesTuristicas;
    }

    @Override
    public String toString() {
        return super.toString() + ", Actividades turisticas: " + actividadesTuristicas;
    }

    @Override
    public void realizarActividad() {
        System.out.println("Las actividades turísticas en el Parque Nacional se pueden realizar.");
    }
}
